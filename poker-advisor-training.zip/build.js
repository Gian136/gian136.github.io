'use strict';
// Packs the trained Q-table into the web page.  node build.js model.json <hands in millions> [out=index.html]
const fs = require('fs'), C = require('./core.js');
const m = JSON.parse(fs.readFileSync(process.argv[2] || 'model.json'));
const MINN = 200, n = C.N_STATES * C.N_ACT;
const q = new Int16Array(n).fill(-32768), est = new Uint8Array(Math.ceil(n / 8));
const idx = (st, h, f, s, o, a) => ((((st * C.N_HS + h) * C.N_FACE + f) * C.N_SPR + s) * C.N_OPP + o) * C.N_ACT + a;
const pack = v => Math.max(-32767, Math.min(32767, Math.round(v * 100)));
let known = 0, filled = 0;
for (let i = 0; i < n; i++) if (m.N[i] >= MINN) { q[i] = pack(m.Q[i]); known++; }

// Situations seen too rarely in training borrow the value of the most similar trained situations
// (same betting round and action; nearby hand strength / opponents / stack depth / bet size), minus a
// small safety discount. They are flagged as estimates.
for (let st = 0; st < 4; st++) for (let a = 0; a < C.N_ACT; a++)
  for (let h = 0; h < C.N_HS; h++) for (let f = 0; f < C.N_FACE; f++) for (let s = 0; s < C.N_SPR; s++) for (let o = 0; o < C.N_OPP; o++) {
    const i = idx(st, h, f, s, o, a);
    if (m.N[i] >= MINN) continue;
    let bestD = 4.01, sum = 0, cnt = 0;
    for (let h2 = 0; h2 < C.N_HS; h2++) for (let f2 = 0; f2 < C.N_FACE; f2++) {
      if ((f === 0) !== (f2 === 0)) continue;                      // never mix "can check" with "facing a bet"
      for (let s2 = 0; s2 < C.N_SPR; s2++) for (let o2 = 0; o2 < C.N_OPP; o2++) {
        const j = idx(st, h2, f2, s2, o2, a);
        if (m.N[j] < MINN) continue;
        const d = Math.abs(h - h2) + 1.5 * Math.abs(o - o2) + 2 * Math.abs(s - s2) + 3 * Math.abs(f - f2);
        if (d < bestD - 1e-9) { bestD = d; sum = m.Q[j]; cnt = 1; }
        else if (Math.abs(d - bestD) < 1e-9) { sum += m.Q[j]; cnt++; }
      }
    }
    if (cnt) { q[i] = pack(sum / cnt - 0.05 * bestD); est[i >> 3] |= 1 << (i & 7); filled++; }
  }

const html = fs.readFileSync('site.template.html', 'utf8')
  .replace('__MODEL_B64__', Buffer.from(q.buffer).toString('base64'))
  .replace('__EST_B64__', Buffer.from(est.buffer).toString('base64'))
  .replace('__HANDS__', process.argv[3] || '80');
fs.writeFileSync(process.argv[4] || 'index.html', html);
console.log(`entries: ${known} trained, ${filled} estimated from neighbours, ${n - known - filled} empty | page ${(html.length / 1024).toFixed(0)} kB`);
