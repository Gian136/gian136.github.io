'use strict';
// Simple rule-based players: used as part of the training population and as benchmark opponents.
const multiway = o => Math.pow(o.hs, o.oppIn);            // rough chance to beat ALL remaining opponents' random hands

// "old page logic": compare the equity vs random hands with the pot odds
const oddsRule = o => {
  const eq = multiway(o);
  if (o.toCall > 0) {
    if (eq > 0.75 && o.ok[3]) return 3;
    return eq > o.toCall / (o.pot + o.toCall) ? 1 : 0;
  }
  return eq > 0.6 && o.ok[2] ? 2 : 1;
};

// A typical loose home-game player. Each one gets its own random habits.
function makeAmateur() {
  const A = { loose: 0, pre: 0, betAt: 0, bluff: 0 };
  A.reroll = () => {
    A.loose = -0.12 + Math.random() * 0.17;               // calls with (equity > pot odds + loose): negative = calls too much
    A.pre = 0.45 + Math.random() * 0.15;                  // plays hands stronger than this before the flop
    A.betAt = 0.55 + Math.random() * 0.15;                // bets when he thinks he is this likely to be ahead
    A.bluff = Math.random() * 0.08;
  };
  A.act = o => {
    const odds = o.toCall / (o.pot + o.toCall);
    if (o.street === 0) {
      if (o.hs > 0.7 && o.ok[3]) return 3;
      if (o.toCall === 0) return 1;
      if (odds > 0.42) return o.hs > 0.66 ? 1 : 0;
      return o.hs > A.pre ? 1 : 0;
    }
    const eq = multiway(o);
    if (o.toCall > 0) {
      if (eq > 0.8 && o.ok[3]) return 3;
      return eq > odds + A.loose ? 1 : 0;
    }
    if (eq > A.betAt + 0.15 && o.ok[3]) return 3;
    if ((eq > A.betAt || Math.random() < A.bluff) && o.ok[2]) return 2;
    return 1;
  };
  A.reroll();
  return A;
}

const station = { act: () => 1 };
const maniac = { act(o) { const r = Math.random(); return r < 0.4 && o.ok[3] ? 3 : r < 0.5 && o.ok[4] ? 4 : 1; } };
const tag = { act(o) {                                    // tight-aggressive rule bot
  const eq = multiway(o), odds = o.toCall / (o.pot + o.toCall);
  if (o.street === 0) {
    if (o.hs > 0.74) return o.ok[3] ? 3 : 1;
    if (o.hs > 0.62) return o.toCall <= 1 ? (o.ok[3] ? 3 : 1) : (odds < 0.42 ? 1 : 0);
    if (o.hs > 0.54) return o.toCall === 0 ? 1 : (o.toCall <= 1 && odds < 0.42 ? 1 : 0);
    return o.toCall > 0 ? 0 : 1;
  }
  if (o.toCall > 0) {
    if (eq > 0.85 && o.ok[3]) return 3;
    return eq > odds + 0.15 ? 1 : 0;
  }
  return eq > 0.65 && o.ok[3] ? 3 : eq > 0.5 && o.ok[2] ? 2 : 1;
} };

module.exports = { oddsRule, makeAmateur, station, maniac, tag };
