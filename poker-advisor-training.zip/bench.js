'use strict';
// Benchmark the trained policy (greedy) against simple rule bots.  node bench.js model.json [hands]
const fs = require('fs'), C = require('./core.js');
const m = JSON.parse(fs.readFileSync(process.argv[2] || 'model.json'));
const HANDS = Number(process.argv[3] || 300000), MINN = 200;
C.setPreflopTable(Float64Array.from(m.pre));
const Q = m.Q, N = m.N;

const B = require('./bots.js'), oddsRule = B.oddsRule;
const MARGIN = 0.02;
const hero = { act(o) {                                   // same decision rule as the web page
  const base = C.stateIndex(o.street, o.hs, o.pot, o.toCall, o.eff, o.oppIn) * 4;
  let best = -1, bq = -Infinity;
  for (let a = 1; a <= 4; a++) if (o.ok[a] && N[base + a - 1] >= MINN && (best < 0 || Q[base + a - 1] > bq + MARGIN)) { bq = Q[base + a - 1]; best = a; }
  if (best < 0) return oddsRule(o);
  if (o.canFold && bq < 0) return 0;
  return best;
} };
function modelAgent(file) {                               // another trained model as opponent
  const o = JSON.parse(fs.readFileSync(file));
  return { act(ob) {
    const base = C.stateIndex(ob.street, ob.hs, ob.pot, ob.toCall, ob.eff, ob.oppIn) * 4;
    let best = -1, bq = -Infinity;
    for (let a = 1; a <= 4; a++) if (ob.ok[a] && o.N[base + a - 1] >= MINN && (best < 0 || o.Q[base + a - 1] > bq + MARGIN)) { bq = o.Q[base + a - 1]; best = a; }
    if (best < 0) return oddsRule(ob);
    return ob.canFold && bq < 0 ? 0 : best;
  } };
}
const am = B.makeAmateur();
const bots = {
  'odds bot (old page logic)': { act: oddsRule },
  'loose amateurs': { act(o) { if (o.street === 0 && Math.random() < 0.2) am.reroll(); return am.act(o); } },
  'calling station': B.station,
  'maniac': B.maniac,
  'tight-aggressive rule bot': B.tag,
};
if (process.argv[4]) bots['model ' + process.argv[4]] = modelAgent(process.argv[4]);

const stacks = new Float64Array(10);
for (const [name, bot] of Object.entries(bots)) {
  let line = name.padEnd(28);
  for (const n of [2, 4, 6]) for (const depth of [30, 100]) {
    let sum = 0, sq = 0;
    for (let h = 0; h < HANDS; h++) {
      const seat = (Math.random() * n) | 0, ag = new Array(n).fill(bot); ag[seat] = hero;
      for (let i = 0; i < n; i++) stacks[i] = depth;
      C.playHand(n, stacks, ag);
      const d = stacks[seat] - depth; sum += d; sq += d * d;
    }
    const mean = sum / HANDS, se = Math.sqrt((sq / HANDS - mean * mean) / HANDS);
    line += ` | ${n}p/${depth}bb ${(mean * 100).toFixed(0).padStart(5)}±${(se * 100).toFixed(0)}`;
  }
  console.log(line);
}
console.log('(hero winnings in big blinds per 100 hands, ± 1 standard error)');
