'use strict';
// Shared poker core: fast evaluator, hand strength, state abstraction, game engine.
// Cards are 0..51: rank = (c >> 2) + 2 (2..14), suit = c & 3.

const SC1 = 16, SC2 = 256, SC3 = 4096, SC4 = 65536, SC5 = 1048576;

function hiBit(m) { return 31 - Math.clz32(m); }
function pop16(m) {
  m = m - ((m >> 1) & 0x5555);
  m = (m & 0x3333) + ((m >> 2) & 0x3333);
  m = (m + (m >> 4)) & 0x0f0f;
  return (m + (m >> 8)) & 0x1f;
}
function straightHigh(m) {
  if (m & 0x4000) m |= 2;                       // ace low
  const t = m & (m >> 1) & (m >> 2) & (m >> 3) & (m >> 4);
  return t ? hiBit(t) + 4 : 0;
}
function topN(m, n) {                            // encode the n highest ranks as base-16 digits (left aligned in 5)
  let s = 0, mult = SC4;
  for (let i = 0; i < n && m; i++) {
    const r = hiBit(m);
    s += r * mult; mult /= 16; m &= ~(1 << r);
  }
  return s;
}

// Best 5 of n (5..7) cards. Higher = better. Category = floor(score / 16^5).
function evaluate(cs, n) {
  let m1 = 0, m2 = 0, m3 = 0, m4 = 0, s0 = 0, s1 = 0, s2 = 0, s3 = 0;
  for (let i = 0; i < n; i++) {
    const c = cs[i], b = 1 << ((c >> 2) + 2);
    m4 |= m3 & b; m3 |= m2 & b; m2 |= m1 & b; m1 |= b;
    switch (c & 3) {
      case 0: s0 |= b; break;
      case 1: s1 |= b; break;
      case 2: s2 |= b; break;
      default: s3 |= b;
    }
  }
  let fm = 0;
  if (n >= 5) {
    if (pop16(s0) >= 5) fm = s0; else if (pop16(s1) >= 5) fm = s1;
    else if (pop16(s2) >= 5) fm = s2; else if (pop16(s3) >= 5) fm = s3;
  }
  if (fm) { const sf = straightHigh(fm); if (sf) return 8 * SC5 + sf * SC4; }
  if (m4) {
    const q = hiBit(m4);
    return 7 * SC5 + q * SC4 + hiBit(m1 & ~(1 << q)) * SC3;
  }
  if (m3) {
    const t = hiBit(m3), rest = m2 & ~(1 << t);
    if (rest) return 6 * SC5 + t * SC4 + hiBit(rest) * SC3;
  }
  if (fm) return 5 * SC5 + topN(fm, 5);
  const st = straightHigh(m1);
  if (st) return 4 * SC5 + st * SC4;
  if (m3) {
    const t = hiBit(m3);
    return 3 * SC5 + t * SC4 + topN(m1 & ~(1 << t), 2) / 16;
  }
  if (m2) {
    const p1 = hiBit(m2), rest = m2 & ~(1 << p1);
    if (rest) {
      const p2 = hiBit(rest);
      return 2 * SC5 + p1 * SC4 + p2 * SC3 + hiBit(m1 & ~(1 << p1) & ~(1 << p2)) * SC2;
    }
    return 1 * SC5 + p1 * SC4 + topN(m1 & ~(1 << p1), 3) / 16;
  }
  return topN(m1, 5);
}

// ---------- state abstraction (shared by trainer and web page) ----------
const HS_EDGES = [0.2, 0.3, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.8, 0.9];   // 12 buckets
const N_HS = 12, N_FACE = 6, N_SPR = 5, N_OPP = 3, N_ACT = 4;                 // actions: call, small, big, all-in
const N_STATES = 4 * N_HS * N_FACE * N_SPR * N_OPP;

function stateIndex(street, hs, pot, toCall, eff, oppIn) {
  let h = 0; while (h < HS_EDGES.length && hs >= HS_EDGES[h]) h++;
  let f = 0;
  if (toCall > 0) {
    const odds = toCall / (pot + toCall);
    f = odds <= 0.22 ? 1 : odds <= 0.31 ? 2 : odds <= 0.42 ? 3 : odds <= 0.46 ? 4 : 5;
  }
  const spr = Math.max(0, eff - toCall) / (pot + toCall);
  const s = spr < 0.5 ? 0 : spr < 2 ? 1 : spr < 6 ? 2 : spr < 15 ? 3 : 4;
  const o = (oppIn >= 3 ? 3 : oppIn) - 1;
  return (((street * N_HS + h) * N_FACE + f) * N_SPR + s) * N_OPP + o;
}

// ---------- hand strength: P(win) + P(tie)/2 against ONE random hand ----------
const _rem = new Uint8Array(52), _me = new Uint8Array(7), _op = new Uint8Array(7);
let PRE = null;                                   // 169-entry preflop table, set by setPreflopTable
function setPreflopTable(t) { PRE = t; }
function preIndex(a, b) {
  const ra = a >> 2, rb = b >> 2, hi = Math.max(ra, rb), lo = Math.min(ra, rb);
  if (hi === lo) return hi * 13 + hi;
  return (a & 3) === (b & 3) ? hi * 13 + lo : lo * 13 + hi;
}

function handStrength(h0, h1, board, nb, flopSamples) {
  if (nb === 0 && PRE) return PRE[preIndex(h0, h1)];
  let k = 0;
  outer: for (let c = 0; c < 52; c++) {
    if (c === h0 || c === h1) continue;
    for (let i = 0; i < nb; i++) if (board[i] === c) continue outer;
    _rem[k++] = c;
  }
  _me[0] = h0; _me[1] = h1;
  for (let i = 0; i < nb; i++) { _me[2 + i] = board[i]; _op[2 + i] = board[i]; }
  let w = 0, tot = 0;
  if (nb === 5) {                                 // exact
    const me = evaluate(_me, 7);
    for (let i = 0; i < k; i++) {
      _op[0] = _rem[i];
      for (let j = i + 1; j < k; j++) {
        _op[1] = _rem[j];
        const o = evaluate(_op, 7);
        w += me > o ? 2 : me === o ? 1 : 0; tot += 2;
      }
    }
  } else if (nb === 4) {                          // every river card x a few random opponent hands
    for (let r = 0; r < k; r++) {
      const river = _rem[r];
      _me[6] = river; _op[6] = river;
      const me = evaluate(_me, 7);
      for (let s = 0; s < 4; s++) {
        let i = (Math.random() * k) | 0; while (i === r) i = (Math.random() * k) | 0;
        let j = (Math.random() * k) | 0; while (j === r || j === i) j = (Math.random() * k) | 0;
        _op[0] = _rem[i]; _op[1] = _rem[j];
        const o = evaluate(_op, 7);
        w += me > o ? 2 : me === o ? 1 : 0; tot += 2;
      }
    }
  } else {                                        // flop (or preflop without table): Monte Carlo
    const need = 5 - nb + 2;
    for (let s = 0; s < flopSamples; s++) {
      for (let i = 0; i < need; i++) {
        const j = i + ((Math.random() * (k - i)) | 0);
        const t = _rem[i]; _rem[i] = _rem[j]; _rem[j] = t;
      }
      for (let i = nb; i < 5; i++) { _me[2 + i] = _rem[i - nb]; _op[2 + i] = _rem[i - nb]; }
      _op[0] = _rem[need - 2]; _op[1] = _rem[need - 1];
      const me = evaluate(_me, 7), o = evaluate(_op, 7);
      w += me > o ? 2 : me === o ? 1 : 0; tot += 2;
    }
  }
  return w / tot;
}

// ---------- game engine: one no-limit hold'em hand, big blind = 1 ----------
const MAXP = 10, RAISE_CAP = 4, FLOP_SAMPLES = 200;
const MAX_SHOVE_SPR = [10, 4, 4, 4];               // all-in only up to this many pots (per street)
const _deck = new Uint8Array(52); for (let i = 0; i < 52; i++) _deck[i] = i;
const _bet = new Float64Array(MAXP), _total = new Float64Array(MAXP);
const _folded = new Uint8Array(MAXP), _acted = new Uint8Array(MAXP);
const _hs = new Float64Array(MAXP * 4), _score = new Float64Array(MAXP);
const _c7 = new Uint8Array(7), _board = new Uint8Array(5);
const FRACS = [0, 0, 0.5, 1];                     // action 2 = half pot, action 3 = pot
// observation object reused for every decision
const O = { p: 0, street: 0, hs: 0, pot: 0, toCall: 0, stack: 0, eff: 0, oppIn: 0,
            canFold: false, put: [0, 0, 0, 0, 0], ok: [false, true, false, false, false] };

// agents[i].act(O) -> action 0 fold, 1 check/call, 2 bet/raise half pot, 3 pot, 4 all-in
function playHand(n, stacks, agents) {
  const need = 5 + 2 * n;
  for (let i = 0; i < need; i++) {
    const j = i + ((Math.random() * (52 - i)) | 0);
    const t = _deck[i]; _deck[i] = _deck[j]; _deck[j] = t;
  }
  for (let i = 0; i < 5; i++) _board[i] = _deck[i];
  let pot = 0, alive = n;
  for (let i = 0; i < n; i++) { _folded[i] = 0; _total[i] = 0; _bet[i] = 0; }
  _hs.fill(-1, 0, n * 4);

  const post = (i, amt) => {
    const a = Math.min(amt, stacks[i]);
    stacks[i] -= a; _bet[i] += a; _total[i] += a; pot += a;
  };
  post(0, 0.5); post(1, 1);

  for (let street = 0; street < 4 && alive > 1; street++) {
    const nb = street === 0 ? 0 : street + 2;
    let curBet = 0, lastRaise = 1, raises = 0;
    if (street === 0) { curBet = Math.max(_bet[0], _bet[1]); raises = 1; }
    else for (let i = 0; i < n; i++) _bet[i] = 0;
    for (let i = 0; i < n; i++) _acted[i] = 0;
    let p = street === 0 ? (n === 2 ? 0 : 2 % n) : (n === 2 ? 1 : 0);
    let idle = 0;
    while (idle < n && alive > 1) {
      let needs = false;
      if (!_folded[p] && stacks[p] > 0) {
        if (_bet[p] < curBet) needs = true;
        else if (!_acted[p]) {
          for (let j = 0; j < n; j++) if (j !== p && !_folded[j] && stacks[j] > 0) { needs = true; break; }
        }
      }
      if (!needs) { idle++; p = (p + 1) % n; continue; }
      idle = 0;

      const toCall = Math.min(curBet - _bet[p], stacks[p]);
      let maxOpp = 0, responders = 0;
      for (let j = 0; j < n; j++) if (j !== p && !_folded[j]) {
        const v = stacks[j] + _bet[j] - _bet[p];
        if (v > maxOpp) maxOpp = v;
        if (stacks[j] > 0) responders++;
      }
      const eff = Math.max(toCall, Math.min(stacks[p], maxOpp));
      const canRaise = stacks[p] > toCall && raises < RAISE_CAP && responders > 0 && eff > toCall;
      let hs = _hs[p * 4 + street];
      if (hs < 0) {
        hs = handStrength(_deck[5 + 2 * p], _deck[6 + 2 * p], _board, nb, FLOP_SAMPLES);
        _hs[p * 4 + street] = hs;
      }
      O.p = p; O.street = street; O.hs = hs; O.pot = pot; O.toCall = toCall;
      O.stack = stacks[p]; O.eff = eff; O.oppIn = alive - 1;
      O.canFold = toCall > 0;
      O.put[1] = toCall; O.ok[1] = true;
      let prevBy = 0;
      for (let a = 2; a <= 3; a++) {
        let by = FRACS[a] * (pot + toCall);
        if (by < lastRaise) by = lastRaise;
        const put = toCall + by;
        O.ok[a] = canRaise && put < 0.999 * eff && by > prevBy;
        O.put[a] = put; prevBy = by;
      }
      O.ok[4] = canRaise && (eff - toCall) <= MAX_SHOVE_SPR[street] * (pot + toCall); O.put[4] = stacks[p];

      let a = agents[p].act(O);
      if (a === 0 && !O.canFold) a = 1;
      if (a > 1 && !O.ok[a]) a = 1;
      if (a === 0) { _folded[p] = 1; alive--; }
      else {
        const put = O.put[a];
        stacks[p] -= put; _bet[p] += put; _total[p] += put; pot += put;
        if (_bet[p] > curBet) {
          const inc = _bet[p] - curBet;
          if (inc > lastRaise) lastRaise = inc;
          curBet = _bet[p]; raises++;
          for (let j = 0; j < n; j++) _acted[j] = 0;
        }
      }
      _acted[p] = 1;
      p = (p + 1) % n;
    }
  }

  // ---------- payout with side pots ----------
  if (alive === 1) {
    for (let i = 0; i < n; i++) if (!_folded[i]) { stacks[i] += pot; break; }
    return;
  }
  for (let i = 0; i < 5; i++) _c7[2 + i] = _board[i];
  for (let i = 0; i < n; i++) if (!_folded[i]) {
    _c7[0] = _deck[5 + 2 * i]; _c7[1] = _deck[6 + 2 * i];
    _score[i] = evaluate(_c7, 7);
  }
  let prev = 0, paid = 0;
  for (;;) {
    let L = Infinity;
    for (let i = 0; i < n; i++) if (!_folded[i] && _total[i] > prev && _total[i] < L) L = _total[i];
    if (L === Infinity) break;
    let chunk = 0, best = -1, cnt = 0;
    for (let i = 0; i < n; i++) {
      chunk += Math.min(_total[i], L) - Math.min(_total[i], prev);
      if (!_folded[i] && _total[i] >= L) {
        if (_score[i] > best) { best = _score[i]; cnt = 1; }
        else if (_score[i] === best) cnt++;
      }
    }
    for (let i = 0; i < n; i++) if (!_folded[i] && _total[i] >= L && _score[i] === best) stacks[i] += chunk / cnt;
    paid += chunk; prev = L;
  }
  if (pot - paid > 1e-9) {                        // dead money above the top live level (should not happen)
    let b = -1; for (let i = 0; i < n; i++) if (!_folded[i] && (b < 0 || _score[i] > _score[b])) b = i;
    stacks[b] += pot - paid;
  }
}

function computePreflopTable(samples) {
  const t = new Float64Array(169);
  const save = PRE; PRE = null;
  for (let hi = 0; hi < 13; hi++) for (let lo = 0; lo <= hi; lo++) {
    if (hi === lo) t[hi * 13 + hi] = handStrength(hi * 4, hi * 4 + 1, _board, 0, samples);
    else {
      t[hi * 13 + lo] = handStrength(hi * 4, lo * 4, _board, 0, samples);       // suited
      t[lo * 13 + hi] = handStrength(hi * 4, lo * 4 + 1, _board, 0, samples);   // offsuit
    }
  }
  PRE = save;
  return t;
}

module.exports = { evaluate, handStrength, stateIndex, playHand, setPreflopTable, computePreflopTable,
                   preIndex, HS_EDGES, N_HS, N_FACE, N_SPR, N_OPP, N_ACT, N_STATES, SC5 };
