# Poker Advisor

`index.html` is the whole website (one file, no dependencies). For GitLab Pages put it in `public/`.

The other files are only needed to retrain the model (Node 18+, no packages):

| File | What it does |
|---|---|
| `core.js` | hand evaluator, hand strength, the model's view of a situation (`stateIndex`), no-limit hold'em engine with side pots |
| `bots.js` | simple rule-based players (training partners and benchmark opponents) |
| `train.js` | self-play reinforcement learning (tabular Monte-Carlo control, softmax exploration) |
| `bench.js` | plays the trained policy against the rule bots |
| `build.js` | packs the Q-table into `site.template.html` and writes `index.html` |
| `pagetest.js` | drives the page in headless Chrome (needs Playwright) |

```
node train.js 16000000 model.json     # 2 workers x 16M hands, about 20 minutes
node bench.js model.json 100000
node build.js model.json 32 index.html
```

The model: `Q[situation][action]` = expected chips won from this decision to the end of the hand, in pots (fold = 0).
Situation = betting round x hand strength vs one random hand (12 buckets) x price to call (6) x stack-to-pot ratio (5) x opponents (1, 2, 3+).
Actions = check/call, bet/raise half pot, bet/raise pot, all-in.
