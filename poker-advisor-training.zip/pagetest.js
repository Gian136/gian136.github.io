'use strict';
const { chromium } = require('playwright'), C = require('./core.js'), path = require('path');
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 900, height: 1300 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + path.resolve(process.argv[2] || 'index.html'));

  // 1) page functions agree with the training code
  const cases = [];
  for (let i = 0; i < 20000; i++) {
    const d = [...Array(52).keys()].sort(() => Math.random() - 0.5).slice(0, 7);
    const st = { street: (Math.random() * 4) | 0, hs: Math.random(), pot: 1 + Math.random() * 100, toCall: Math.random() < 0.4 ? 0 : Math.random() * 150, eff: Math.random() * 600, opp: 1 + ((Math.random() * 9) | 0) };
    cases.push({ d, st, ev: C.evaluate(d, 7), idx: C.stateIndex(st.street, st.hs, st.pot, st.toCall, st.eff, st.opp) });
  }
  const bad = await page.evaluate(cs => cs.filter(c => evaluate(c.d, 7) !== c.ev || stateIndex(c.st.street, c.st.hs, c.st.pot, c.st.toCall, c.st.eff, c.st.opp) !== c.idx).length, cases);
  console.log('evaluate/stateIndex mismatches vs trainer:', bad, '| model entries:', await page.evaluate(() => MODEL.length));

  const card = (r, s) => (r - 2) * 4 + s;                 // suits: 0 ♠ 1 ♥ 2 ♦ 3 ♣
  const tap = async c => page.click(`.card[data-c="${c}"]`);
  const read = async () => page.evaluate(() => ({ move: document.getElementById('move').textContent, sub: document.getElementById('moveSub').textContent,
    why: document.getElementById('why').textContent, opts: [...document.querySelectorAll('.opt')].map(o => o.innerText.replace(/\s+/g, ' ')).join(' | '),
    facts: document.getElementById('facts').textContent, stage: document.getElementById('stage').textContent, lose: document.getElementById('lose').textContent }));
  const show = async label => { const r = await read(); console.log(`\n[${label}] ${r.stage} -> ${r.move}  (${r.sub})\n   ${r.why}\n   ${r.opts}\n   ${r.facts}`); };
  const set = async (id, v) => page.fill('#' + id, String(v));
  const newHand = async () => page.click('#newHand');
  const opp = async n => page.click(`.pbtn[data-n="${n}"]`);

  console.log('\n[empty]', JSON.stringify(await read()));
  await set('mTotal', 600); await set('mPlayers', 6); await set('mStack', 100);

  // A: pocket aces, 5 opponents, facing the big blind
  await opp(5); await tap(card(14, 0)); await tap(card(14, 1)); await set('mPot', 3); await set('mCall', 2); await show('AA preflop vs 5, call 2 into 3');
  // B: 7-2 offsuit same spot
  await newHand(); await tap(card(7, 0)); await tap(card(2, 1)); await set('mPot', 3); await set('mCall', 2); await show('72o preflop vs 5');
  // C: K-Q suited facing a raise heads-up
  await newHand(); await opp(1); await tap(card(13, 2)); await tap(card(12, 2)); await set('mPot', 9); await set('mCall', 4); await show('KQs preflop vs 1, call 4 into 9');
  // D: flop top pair, checked to us, 2 opponents
  await newHand(); await opp(2); await tap(card(14, 0)); await tap(card(11, 1)); await set('mPot', 12); await set('mCall', 0);
  await tap(card(14, 2)); await tap(card(7, 3)); await show('AJ with 2 flop cards only');
  await tap(card(3, 0)); await show('AJ on A-7-3 flop, no bet, vs 2');
  // E: same hand, turn, facing a pot-size bet
  await tap(card(9, 1)); await set('mPot', 48); await set('mCall', 24); await show('AJ on A-7-3-9 turn, call 24 into 48');
  // F: river, missed everything, facing a small bet
  await newHand(); await opp(1); await tap(card(8, 0)); await tap(card(7, 0)); await set('mPot', 40); await set('mCall', 10);
  for (const c of [card(14, 1), card(13, 2), card(4, 3), card(2, 1), card(10, 2)]) await tap(c);
  await show('87 missed on river, call 10 into 40');
  // G: river nuts, checked to us
  await newHand(); await tap(card(14, 0)); await tap(card(13, 0)); await set('mPot', 40); await set('mCall', 0);
  for (const c of [card(12, 0), card(11, 0), card(10, 0), card(2, 1), card(3, 2)]) await tap(c);
  await show('royal flush on river, no bet');
  // H: short stack, facing an all-in sized bet with a medium pair
  await newHand(); await set('mStack', 18); await tap(card(9, 0)); await tap(card(9, 1)); await set('mPot', 23); await set('mCall', 18); await show('99 preflop, stack 18, call 18 into 23');
  // I: no "total" given, undo, remove via slot
  await set('mTotal', ''); await show('same without total money');
  await page.click('#undo'); console.log('\n[after undo]', (await read()).move);
  await set('mStack', 100); await set('mTotal', 600);

  await newHand(); await opp(2); await tap(card(14, 0)); await tap(card(11, 1)); await set('mPot', 48); await set('mCall', 24);
  for (const c of [card(14, 2), card(7, 3), card(3, 0), card(9, 1)]) await tap(c);
  await page.screenshot({ path: 'shot-desktop.png', fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: 'shot-mobile.png', fullPage: true });
  console.log('\npage errors:', errors.length ? errors : 'none');
  await browser.close();
})();
