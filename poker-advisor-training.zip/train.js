'use strict';
// Self-play reinforcement learning for the poker advisor.
//   node train.js <hands per worker> [out=model.json] [in=model.json to continue from] [tau0 tau1 eps0 eps1 alpha0 alpha1]
// Tabular Monte-Carlo control: seats are played by the same Q-table (softmax exploration),
// mixed with some loose rule-based players so the policy also learns to play against amateurs.
// Q[state][action] = expected chips won from this decision to the end of the hand,
//                    in units of the pot at decision time (folding = 0).
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const fs = require('fs');
const C = require('./core.js');
const B = require('./bots.js');
const AMATEUR_SHARE = 0.35;                      // share of seats played by loose rule-based "home game" players
const SIZE = C.N_STATES * C.N_ACT;

function makeLearner(Q, Nv) {
  const L = { tau: 0.3, eps: 0.1, alphaMin: 1e-3, n: 0,
              lp: new Int32Array(256), li: new Int32Array(256), lpot: new Float64Array(256), lst: new Float64Array(256) };
  const q = [0, 0, 0, 0, 0], av = [0, 0, 0, 0, 0];
  L.act = function (o) {
    const base = C.stateIndex(o.street, o.hs, o.pot, o.toCall, o.eff, o.oppIn) * C.N_ACT;
    let k = 0;
    if (o.canFold) { av[k] = 0; q[k++] = 0; }
    for (let a = 1; a <= 4; a++) if (o.ok[a]) { av[k] = a; q[k++] = Q[base + a - 1]; }
    let pick = 0;
    if (Math.random() < L.eps) pick = (Math.random() * k) | 0;
    else {
      let mx = -Infinity; for (let i = 0; i < k; i++) if (q[i] > mx) mx = q[i];
      let sum = 0; for (let i = 0; i < k; i++) { q[i] = Math.exp((q[i] - mx) / L.tau); sum += q[i]; }
      let r = Math.random() * sum;
      for (pick = 0; pick < k - 1; pick++) { r -= q[pick]; if (r <= 0) break; }
    }
    const a = av[pick];
    if (a > 0 && L.n < 256) { L.lp[L.n] = o.p; L.li[L.n] = base + a - 1; L.lpot[L.n] = o.pot; L.lst[L.n] = o.stack; L.n++; }
    return a;
  };
  L.learn = function (stacks) {
    for (let i = 0; i < L.n; i++) {
      const idx = L.li[i], G = (stacks[L.lp[i]] - L.lst[i]) / L.lpot[i];
      const n = ++Nv[idx], alpha = Math.max(1 / n, L.alphaMin);
      Q[idx] += alpha * (G - Q[idx]);
    }
    L.n = 0;
  };
  return L;
}

function randomTable(stacks) {                     // table size and stack depths (in big blinds)
  const n = 2 + ((Math.random() * 6) | 0);         // 2..7 players
  if (Math.random() < 0.5) {
    const s = Math.exp(Math.log(5) + Math.random() * Math.log(60));          // everyone equal, 5..300 BB
    for (let i = 0; i < n; i++) stacks[i] = s;
  } else for (let i = 0; i < n; i++) stacks[i] = Math.exp(Math.log(5) + Math.random() * Math.log(60));
  return n;
}

if (isMainThread && require.main === module) {
  const hands = Number(process.argv[2] || 1e6), out = process.argv[3] || 'model.json', inp = process.argv[4];
  const sched = (process.argv.slice(5).map(Number).length === 6) ? process.argv.slice(5).map(Number) : [0.5, 0.08, 0.15, 0.02, 2e-3, 2e-4];
  const qb = new SharedArrayBuffer(SIZE * 8), nb = new SharedArrayBuffer(SIZE * 8);
  const Q = new Float64Array(qb), Nv = new Float64Array(nb);
  let pre;
  if (inp && inp !== '-') {
    const m = JSON.parse(fs.readFileSync(inp)); Q.set(m.Q); Nv.set(m.N); pre = Float64Array.from(m.pre);
  } else pre = C.computePreflopTable(300000);
  const W = 2; let done = 0; const t0 = Date.now();
  for (let w = 0; w < W; w++) {
    const wk = new Worker(__filename, { workerData: { qb, nb, pre, hands, sched } });
    wk.on('message', m => { if (m.progress !== undefined && w === 0) console.log(`${(m.progress * 100).toFixed(0)}%  ${((Date.now() - t0) / 1000).toFixed(0)}s`); });
    wk.on('exit', () => {
      if (++done === W) {
        fs.writeFileSync(out, JSON.stringify({ Q: Array.from(Q), N: Array.from(Nv), pre: Array.from(pre) }));
        console.log('saved', out, 'total hands', hands * W, 'in', ((Date.now() - t0) / 1000).toFixed(0), 's');
      }
    });
  }
} else if (!isMainThread) {
  const { qb, nb, pre, hands, sched } = workerData;
  const Q = new Float64Array(qb), Nv = new Float64Array(nb);
  C.setPreflopTable(pre);
  const L = makeLearner(Q, Nv), agents = new Array(10).fill(L), stacks = new Float64Array(10);
  const amateurs = []; for (let i = 0; i < 10; i++) amateurs.push(B.makeAmateur());
  const [tau0, tau1, eps0, eps1, al0, al1] = sched;
  for (let h = 0; h < hands; h++) {
    if (h % 2000 === 0) {
      const f = h / hands;
      L.tau = tau0 * Math.pow(tau1 / tau0, f);
      L.eps = eps0 * Math.pow(eps1 / eps0, f);
      L.alphaMin = al0 * Math.pow(al1 / al0, f);
      if (h % (Math.ceil(hands / 20000) * 2000) === 0) parentPort.postMessage({ progress: f });
    }
    const n = randomTable(stacks);
    let learners = 0;                              // population: copies of the learner + some amateurs
    for (let i = 0; i < n; i++) {
      if (Math.random() < AMATEUR_SHARE) { amateurs[i].reroll(); agents[i] = amateurs[i]; }
      else { agents[i] = L; learners++; }
    }
    if (!learners) agents[(Math.random() * n) | 0] = L;
    C.playHand(n, stacks, agents);
    L.learn(stacks);
  }
}

module.exports = { makeLearner, randomTable };
